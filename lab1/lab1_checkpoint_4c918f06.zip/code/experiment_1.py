
import json
import shutil
import time
from pathlib import Path
from uuid import uuid4
from openai import OpenAI

ROOT = Path("/content/lab1_artifacts")

# Прогноз должен быть сохранён до основных измерений.
forecast = ROOT / "forecasts/lab1.md"
if not forecast.exists():
    raise FileNotFoundError("Сначала сохрани предварительный прогноз")

sources = list((ROOT / "data").glob("prompts_exp1_*.jsonl"))
source = max(sources, key=lambda p: p.stat().st_mtime)
records = [
    json.loads(line)
    for line in source.read_text(encoding="utf-8").splitlines()
    if line.strip()
]

assert len(records) == 25
for length in [256, 1024, 4096, 8192, 16384]:
    assert sum(r["target_prompt_tokens"] == length for r in records) == 5

# Новая папка для каждого запуска: старые результаты сохраняются.
run_dir = ROOT / "exp1" / uuid4().hex
run_dir.mkdir(parents=True)
shutil.copyfile(source, run_dir / "prompts.jsonl")
shutil.copyfile(forecast, run_dir / "forecast.md")
shutil.copyfile("/content/server_command.txt", run_dir / "server_command.txt")

client = OpenAI(
    base_url="http://127.0.0.1:8000/v1",
    api_key="none",
    timeout=300,
)

params = {
    "model": "Qwen/Qwen3-4B-Instruct-2507",
    "temperature": 0,
    "top_p": 1,
    "presence_penalty": 0,
    "frequency_penalty": 0,
    "seed": 0,
    "max_tokens": 16,
    "stream": True,
    "stream_options": {"include_usage": True},
    "extra_body": {
        "ignore_eos": True,
        "top_k": -1,
        "repetition_penalty": 1.0,
    },
}
(run_dir / "generation.json").write_text(
    json.dumps(params, indent=2), encoding="utf-8"
)


def measure(record, filename, kind):
    result = {
        "request_id": record["request_id"],
        "kind": kind,
        "target_prompt_tokens": record["target_prompt_tokens"],
        "text_chunk_times": [],
        "text_chunks": [],
    }

    try:
        usage = None
        finish_reason = None
        result["t0"] = time.perf_counter()

        with client.chat.completions.create(
            messages=record["messages"], **params
        ) as stream:
            for chunk in stream:
                if chunk.usage is not None:
                    usage = chunk.usage

                if chunk.choices:
                    choice = chunk.choices[0]
                    if choice.finish_reason is not None:
                        finish_reason = choice.finish_reason
                    if choice.delta.content:
                        result["text_chunk_times"].append(time.perf_counter())
                        result["text_chunks"].append(choice.delta.content)

        times = result["text_chunk_times"]
        if usage is None or not times:
            raise ValueError("Не получены текст или сведения о токенах")

        result.update({
            "prompt_tokens": usage.prompt_tokens,
            "output_tokens": usage.completion_tokens,
            "finish_reason": finish_reason,
            "ttft_s": times[0] - result["t0"],
            "e2e_s": times[-1] - result["t0"],
        })

        if usage.prompt_tokens != record["target_prompt_tokens"]:
            raise ValueError("Не совпала длина запроса")
        if usage.completion_tokens != 16:
            raise ValueError("Ответ должен содержать 16 токенов")

        result["tpot_s"] = (times[-1] - times[0]) / 15
        result["status"] = "completed"

    except Exception as error:
        result["status"] = "failed"
        result["error"] = repr(error)
        raise

    finally:
        # Сохраняем и успешный результат, и сведения об ошибке.
        with (run_dir / filename).open("a", encoding="utf-8") as file:
            file.write(json.dumps(result, ensure_ascii=False) + "\n")

    return result


# Прогрев сохраняем отдельно и не включаем в основные результаты.
print("Прогрев...", flush=True)
measure(records[0], "warmup.jsonl", "warmup")

for number, record in enumerate(records, start=1):
    result = measure(record, "results.jsonl", "experiment_1")
    print(
        f"{number}/25 | вход: {result['prompt_tokens']} | "
        f"TTFT: {result['ttft_s'] * 1000:.1f} мс | "
        f"TPOT: {result['tpot_s'] * 1000:.1f} мс/токен",
        flush=True,
    )

print("ЭКСПЕРИМЕНТ ЗАВЕРШЁН")
print("Результаты:", run_dir)
