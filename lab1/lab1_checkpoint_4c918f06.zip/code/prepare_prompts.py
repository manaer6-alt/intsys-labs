
# Создаёт 25 запросов заданной длины, не запуская генерацию ответов.
import hashlib
import json
from pathlib import Path
from uuid import uuid4
from transformers import AutoTokenizer

ROOT = Path("/content/lab1_artifacts")
DATA = ROOT / "data"
MODEL = "Qwen/Qwen3-4B-Instruct-2507"

# Проверяем, что исходный файл книги не изменился.
raw = (DATA / "pride_and_prejudice.txt").read_bytes()
manifest = json.loads((DATA / "manifest.json").read_text(encoding="utf-8"))
assert hashlib.sha256(raw).hexdigest() == manifest["sha256"]

text = raw.decode("utf-8-sig")

# Отделяем текст издания от служебной шапки и лицензии Gutenberg.
start = text.index("*** START OF")
start = text.index("\n", start) + 1
end = text.index("*** END OF", start)
text = text[start:end].strip()

# Загружается только токенизатор, уже скачанный сервером.
# Второй экземпляр модели в видеопамять не загружаем.
tokenizer = AutoTokenizer.from_pretrained(MODEL, local_files_only=True)
book_tokens = tokenizer.encode(text, add_special_tokens=False)


def count_tokens(messages):
    # Учитываем оформление диалога и начало ответа ассистента.
    formatted = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    return len(tokenizer.encode(formatted, add_special_tokens=False))


def make_prompt(target, request_id):
    header = (
        f"Request ID: {request_id}\n"
        "Summarize the following text in one sentence.\n\n"
    )

    # Оставляем место для инструкции и служебных токенов.
    messages = [{"role": "user", "content": header}]
    budget = target - count_tokens(messages)

    # Проверяем итоговую длину: на границах частей токенизация может меняться.
    for _ in range(20):
        if not 0 < budget <= len(book_tokens):
            raise ValueError("Недостаточно текста или слишком малая длина")

        fragment = tokenizer.decode(book_tokens[:budget])
        messages = [{"role": "user", "content": header + fragment}]
        actual = count_tokens(messages)

        if actual == target:
            return messages

        budget += target - actual

    raise ValueError(f"Не удалось получить ровно {target} токенов")


batch_id = uuid4().hex
records = []

for length in [256, 1024, 4096, 8192, 16384]:
    for repeat in range(5):
        request_id = f"{batch_id}-{length}-{repeat}"
        messages = make_prompt(length, request_id)
        records.append({
            "request_id": request_id,
            "target_prompt_tokens": length,
            "messages": messages,
        })

path = DATA / f"prompts_exp1_{batch_id}.jsonl"
path.write_text(
    "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in records),
    encoding="utf-8",
)

print("Подготовлено запросов:", len(records))
for length in [256, 1024, 4096, 8192, 16384]:
    counts = [
        count_tokens(r["messages"])
        for r in records if r["target_prompt_tokens"] == length
    ]
    print(f"Целевая длина {length}: {counts}")

print("Сохранено:", path)
